package SmallZoo;

public class Hunter implements Animal {

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("�������");
	}

	@Override
	public void name() {
		// TODO Auto-generated method stub
		System.out.println("��ɲ�");
	}

}
