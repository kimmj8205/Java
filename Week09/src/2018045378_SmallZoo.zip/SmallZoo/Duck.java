package SmallZoo;

public class Duck implements Animal {

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("�ڶ׵ڶ�");

	}

	@Override
	public void name() {
		// TODO Auto-generated method stub
		System.out.println("������");
	}

}
