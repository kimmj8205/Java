package SmallZoo;

public class Chick implements Animal {

	@Override
	public void sound() {
		System.out.println("�߾�߾�");

	}

	@Override
	public void name() {
		// TODO Auto-generated method stub
		System.out.println("���Ƹ�");
	}

}
