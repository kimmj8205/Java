package SmallZoo;

public interface Animal {
	public void sound();
	public void name();

}
