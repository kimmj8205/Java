package SmallZoo;

public class Zoo {

	public static void main(String[] args) {
		Chick chick = new Chick();
		Calf calf = new Calf();
		Hunter hunter = new Hunter();
		Duck duck = new Duck();
		Frog frog = new Frog();
		Crawfish crawfish = new Crawfish();
		Shell shell = new Shell();
		chick.sound();
		chick.name();
		calf.sound();
		calf.name();
		hunter.sound();
		hunter.name();
		duck.sound();
		duck.name();
		frog.sound();
		frog.name();
		crawfish.sound();
		crawfish.name();
		shell.sound();
		shell.name();

	}

}
