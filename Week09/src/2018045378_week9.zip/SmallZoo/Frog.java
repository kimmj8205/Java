package SmallZoo;

public class Frog implements Animal {

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("Ǫ Ǫ");
	}

	@Override
	public void name() {
		// TODO Auto-generated method stub
		System.out.println("������");
	}

}
